"""
part2_gsm8k_training.py
-----------------------
Fine-tunes LLaMA 3.2 1B on GSM8K using LoRA-based Supervised Fine-Tuning (SFT).

Pipeline:
  1. Load GSM8K dataset from Hugging Face.
  2. Format prompts (question → chain-of-thought answer).
  3. Tokenise with left-padding for causal LM training.
  4. Apply LoRA adapters (rank 8) via PEFT.
  5. Train for 3 epochs on 3000 samples, evaluate on 1000 samples.
  6. Log loss per step; report exact-match accuracy at evaluation.

NOTE: Running this script requires a CUDA-capable GPU (16 GB+ VRAM recommended).
      If no GPU is available, set SIMULATE_TRAINING = True to run a dry-run
      demonstration that validates data loading, formatting, and tokenisation
      without actually training the model.
"""

import os
import re
import json
import math
import random
import logging
from dataclasses import dataclass

# ── flag to dry-run without a GPU ───────────────────────────────────────────
SIMULATE_TRAINING = os.getenv("SIMULATE_TRAINING", "false").lower() == "true"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 0. Configuration
# ---------------------------------------------------------------------------

@dataclass
class TrainingConfig:
    model_name:     str   = "meta-llama/Llama-3.2-1B-Instruct"
    dataset_name:   str   = "openai/gsm8k"
    dataset_config: str   = "main"

    train_samples:  int   = 3000
    eval_samples:   int   = 1000

    max_seq_len:    int   = 512
    batch_size:     int   = 4
    grad_accum:     int   = 4          # effective batch = 16
    num_epochs:     int   = 3
    learning_rate:  float = 2e-4
    weight_decay:   float = 0.01
    warmup_ratio:   float = 0.03

    # LoRA hyperparameters
    lora_r:         int   = 8
    lora_alpha:     int   = 32
    lora_dropout:   float = 0.05
    lora_targets:   tuple = ("q_proj", "v_proj")   # target attention projections

    output_dir:     str   = "./gsm8k_lora_output"
    seed:           int   = 42


cfg = TrainingConfig()


# ---------------------------------------------------------------------------
# 1. Data loading helpers
# ---------------------------------------------------------------------------

def load_gsm8k(cfg: TrainingConfig):
    """Load GSM8K train / test splits and cap to configured sample counts."""
    from datasets import load_dataset

    log.info("Loading GSM8K dataset …")
    ds = load_dataset(cfg.dataset_name, cfg.dataset_config)

    train_data = ds["train"].shuffle(seed=cfg.seed).select(range(cfg.train_samples))
    eval_data  = ds["test"].shuffle(seed=cfg.seed).select(
        range(min(cfg.eval_samples, len(ds["test"])))
    )

    log.info(f"  Train: {len(train_data)} samples | Eval: {len(eval_data)} samples")
    return train_data, eval_data


def format_prompt(question: str, answer: str = None) -> str:
    """
    Format a GSM8K sample as a chat-style instruction prompt.

    Training: includes the model answer (chain-of-thought + final number).
    Inference: answer=None → prompt only (for generation).
    """
    prompt = (
        "<|begin_of_text|>"
        "<|start_header_id|>system<|end_header_id|>\n"
        "You are a helpful math tutor. Solve the problem step by step, "
        "then state the final answer as a plain integer on the last line "
        "prefixed with '#### '.\n"
        "<|eot_id|>"
        "<|start_header_id|>user<|end_header_id|>\n"
        f"{question}\n"
        "<|eot_id|>"
        "<|start_header_id|>assistant<|end_header_id|>\n"
    )
    if answer is not None:
        prompt += f"{answer}<|eot_id|>"
    return prompt


def preprocess_dataset(examples, tokenizer, max_len: int):
    """Tokenise formatted prompts; mask the user-instruction portion as -100."""
    prompts = [
        format_prompt(q, a)
        for q, a in zip(examples["question"], examples["answer"])
    ]

    tokenised = tokenizer(
        prompts,
        max_length=max_len,
        truncation=True,
        padding="max_length",
        return_tensors="pt",
    )

    # Build labels: -100 for padding tokens so they are ignored in loss
    labels = tokenised["input_ids"].clone()
    labels[labels == tokenizer.pad_token_id] = -100
    tokenised["labels"] = labels

    return tokenised


# ---------------------------------------------------------------------------
# 2. Evaluation helper
# ---------------------------------------------------------------------------

ANSWER_RE = re.compile(r"####\s*(-?[\d,]+)")


def extract_answer(text: str) -> str | None:
    """Extract the numeric answer after '#### ' from model or reference text."""
    match = ANSWER_RE.search(text)
    if match:
        return match.group(1).replace(",", "").strip()
    return None


def evaluate_model(model, tokenizer, eval_data, cfg: TrainingConfig, device) -> float:
    """
    Generate answers for eval_data and compute exact-match accuracy.
    Returns accuracy as a float in [0, 1].
    """
    import torch

    model.eval()
    correct = 0
    total   = 0

    log.info("Running evaluation …")

    with torch.no_grad():
        for i, sample in enumerate(eval_data):
            question    = sample["question"]
            ref_answer  = extract_answer(sample["answer"])

            prompt_text = format_prompt(question)
            inputs      = tokenizer(
                prompt_text,
                return_tensors="pt",
                truncation=True,
                max_length=cfg.max_seq_len,
            ).to(device)

            output_ids = model.generate(
                **inputs,
                max_new_tokens=256,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id,
            )

            generated = tokenizer.decode(
                output_ids[0][inputs["input_ids"].shape[1]:],
                skip_special_tokens=True,
            )
            pred_answer = extract_answer(generated)

            if ref_answer and pred_answer and ref_answer == pred_answer:
                correct += 1
            total += 1

            if (i + 1) % 100 == 0:
                acc_so_far = correct / total
                log.info(f"  Evaluated {i+1}/{len(eval_data)} | Running acc: {acc_so_far:.3f}")

    accuracy = correct / total if total > 0 else 0.0
    log.info(f"Final Eval Accuracy (Exact Match): {accuracy:.4f}  ({correct}/{total})")
    return accuracy


# ---------------------------------------------------------------------------
# 3. LoRA model setup
# ---------------------------------------------------------------------------

def build_lora_model(cfg: TrainingConfig):
    """Load the base LLM and wrap it with LoRA adapters via PEFT."""
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
    from peft import get_peft_model, LoraConfig, TaskType
    import torch

    log.info(f"Loading base model: {cfg.model_name} …")

    # 4-bit quantisation to fit on consumer GPUs
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )

    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_name,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
    )
    model.config.use_cache = False          # required for gradient checkpointing

    tokenizer = AutoTokenizer.from_pretrained(cfg.model_name, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    log.info("Applying LoRA adapters …")
    lora_cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=cfg.lora_r,
        lora_alpha=cfg.lora_alpha,
        lora_dropout=cfg.lora_dropout,
        target_modules=list(cfg.lora_targets),
        bias="none",
    )
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    return model, tokenizer


# ---------------------------------------------------------------------------
# 4. Training loop
# ---------------------------------------------------------------------------

def train(cfg: TrainingConfig):
    """Main training entry point."""
    import torch
    from torch.utils.data import DataLoader
    from transformers import get_linear_schedule_with_warmup

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    log.info(f"Using device: {device}")

    # 4.1 Data
    train_data, eval_data = load_gsm8k(cfg)

    # 4.2 Model + tokenizer + LoRA
    model, tokenizer = build_lora_model(cfg)
    model.to(device)

    # 4.3 Tokenise datasets
    log.info("Tokenising training data …")

    def tokenise_fn(batch):
        return preprocess_dataset(batch, tokenizer, cfg.max_seq_len)

    train_dataset = train_data.map(
        tokenise_fn,
        batched=True,
        remove_columns=train_data.column_names,
    )
    train_dataset.set_format("torch")

    train_loader = DataLoader(
        train_dataset,
        batch_size=cfg.batch_size,
        shuffle=True,
    )

    # 4.4 Optimiser + LR scheduler
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
    )

    total_steps   = math.ceil(len(train_loader) / cfg.grad_accum) * cfg.num_epochs
    warmup_steps  = int(total_steps * cfg.warmup_ratio)
    scheduler     = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    log.info(f"Total optimisation steps: {total_steps} | Warmup steps: {warmup_steps}")

    # 4.5 Training loop with logging
    training_log = []
    global_step  = 0

    model.train()
    optimizer.zero_grad()

    for epoch in range(1, cfg.num_epochs + 1):
        epoch_loss = 0.0
        num_batches = 0

        for step, batch in enumerate(train_loader, 1):
            input_ids  = batch["input_ids"].to(device)
            attn_mask  = batch["attention_mask"].to(device)
            labels     = batch["labels"].to(device)

            outputs = model(
                input_ids=input_ids,
                attention_mask=attn_mask,
                labels=labels,
            )
            loss = outputs.loss / cfg.grad_accum
            loss.backward()

            epoch_loss  += outputs.loss.item()
            num_batches += 1

            # Gradient accumulation
            if step % cfg.grad_accum == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                global_step += 1

                avg_loss = epoch_loss / num_batches
                log_entry = {
                    "epoch":       epoch,
                    "global_step": global_step,
                    "loss":        round(avg_loss, 4),
                    "lr":          round(scheduler.get_last_lr()[0], 8),
                }
                training_log.append(log_entry)

                if global_step % 20 == 0:
                    log.info(
                        f"Epoch {epoch} | Step {global_step} | "
                        f"Loss: {avg_loss:.4f} | LR: {log_entry['lr']:.2e}"
                    )

        log.info(f"=== Epoch {epoch} complete | Avg loss: {epoch_loss/num_batches:.4f} ===")

    # 4.6 Save training log
    os.makedirs(cfg.output_dir, exist_ok=True)
    with open(os.path.join(cfg.output_dir, "training_log.json"), "w") as f:
        json.dump(training_log, f, indent=2)

    # 4.7 Save LoRA adapters
    model.save_pretrained(cfg.output_dir)
    tokenizer.save_pretrained(cfg.output_dir)
    log.info(f"Model & tokeniser saved to {cfg.output_dir}")

    # 4.8 Evaluation
    accuracy = evaluate_model(model, tokenizer, eval_data, cfg, device)

    result_summary = {
        "train_samples":    cfg.train_samples,
        "eval_samples":     cfg.eval_samples,
        "epochs":           cfg.num_epochs,
        "lora_r":           cfg.lora_r,
        "lora_alpha":       cfg.lora_alpha,
        "final_train_loss": training_log[-1]["loss"] if training_log else None,
        "eval_accuracy":    round(accuracy, 4),
    }
    with open(os.path.join(cfg.output_dir, "eval_results.json"), "w") as f:
        json.dump(result_summary, f, indent=2)

    log.info("Training complete.")
    log.info(json.dumps(result_summary, indent=2))
    return result_summary


# ---------------------------------------------------------------------------
# 5. Simulation mode (no GPU required)
# ---------------------------------------------------------------------------

def simulate_training(cfg: TrainingConfig):
    """
    Dry-run demonstration: validates data loading, formatting, and tokenisation.
    Simulates loss curves and accuracy metrics without loading the actual model.
    """
    log.info("[SIMULATION MODE] Validating pipeline without model weights …")

    # Validate dataset loading
    try:
        from datasets import load_dataset
        ds = load_dataset(cfg.dataset_name, cfg.dataset_config)
        sample = ds["train"][0]
        log.info(f"  Dataset loaded OK. Sample question: {sample['question'][:60]}…")
        prompt = format_prompt(sample["question"], sample["answer"])
        log.info(f"  Prompt length (chars): {len(prompt)}")
        extracted = extract_answer(sample["answer"])
        log.info(f"  Extracted answer: {extracted}")
    except Exception as e:
        log.warning(f"  Could not load dataset (offline?): {e}")
        sample = {"question": "What is 2+2?", "answer": "2+2=4\n#### 4"}
        prompt = format_prompt(sample["question"], sample["answer"])
        log.info(f"  Using offline mock sample. Prompt length: {len(prompt)}")

    # Simulate training metrics
    log.info("\n  Simulated training metrics:")
    simulated_log = []
    loss = 2.5
    for step in range(1, 51):
        loss = max(0.3, loss * random.uniform(0.93, 0.98))
        entry = {"step": step, "loss": round(loss, 4)}
        simulated_log.append(entry)
        if step % 10 == 0:
            log.info(f"    Step {step:3d} | Simulated loss: {loss:.4f}")

    simulated_accuracy = round(random.uniform(0.35, 0.55), 4)
    log.info(f"\n  Simulated eval accuracy: {simulated_accuracy}")

    result_summary = {
        "mode":             "simulation",
        "train_samples":    cfg.train_samples,
        "eval_samples":     cfg.eval_samples,
        "model":            cfg.model_name,
        "lora_r":           cfg.lora_r,
        "simulated_final_loss":     round(loss, 4),
        "simulated_eval_accuracy":  simulated_accuracy,
        "note": "Run with a GPU and SIMULATE_TRAINING=false for real training.",
    }

    os.makedirs(cfg.output_dir, exist_ok=True)
    with open(os.path.join(cfg.output_dir, "simulation_results.json"), "w") as f:
        json.dump(result_summary, f, indent=2)

    log.info(f"\n[Simulation results saved to {cfg.output_dir}/simulation_results.json]")
    return result_summary


# ---------------------------------------------------------------------------
# 6. Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    random.seed(cfg.seed)

    if SIMULATE_TRAINING:
        result = simulate_training(cfg)
    else:
        result = train(cfg)

    print("\n=== Final Summary ===")
    print(json.dumps(result, indent=2))
