"""
part1_ingestion.py
------------------
Sliding Window + Knowledge Pyramid document ingestion system.

Architecture:
  Raw Text  →  Chunk Summary  →  Category/Theme  →  Distilled Knowledge
  (Layer 0)      (Layer 1)          (Layer 2)           (Layer 3)

Each document page is split via a 2-page sliding window (character-based),
then each window is enriched into a 4-layer Knowledge Pyramid entry.
At query time, cosine similarity is used to find the best match across all layers.
"""

import re
import math
import json
from collections import Counter


# ---------------------------------------------------------------------------
# SECTION 1: Sliding Window Chunker
# ---------------------------------------------------------------------------

CHARS_PER_PAGE = 2000          # approximate characters representing one page
WINDOW_PAGES   = 2             # window size in pages
SLIDE_PAGES    = 1             # slide step in pages


def sliding_window_chunks(text: str) -> list[dict]:
    """
    Split document text into overlapping 2-page windows.

    Returns a list of dicts:
        { "chunk_id": int, "text": str, "start_char": int, "end_char": int }
    """
    window_size = CHARS_PER_PAGE * WINDOW_PAGES   # 4000 chars
    step_size   = CHARS_PER_PAGE * SLIDE_PAGES    # 2000 chars

    chunks = []
    chunk_id = 0
    start = 0

    while start < len(text):
        end   = min(start + window_size, len(text))
        chunk = text[start:end].strip()

        if chunk:
            chunks.append({
                "chunk_id":   chunk_id,
                "text":       chunk,
                "start_char": start,
                "end_char":   end,
            })
            chunk_id += 1

        if end == len(text):          # reached document end
            break
        start += step_size            # slide forward by 1 page

    return chunks


# ---------------------------------------------------------------------------
# SECTION 2: Knowledge Pyramid Layers
# ---------------------------------------------------------------------------

def layer0_raw(chunk: dict) -> str:
    """Layer 0 – Raw Text: the verbatim chunk content."""
    return chunk["text"]


def layer1_summary(raw_text: str) -> str:
    """
    Layer 1 – Chunk Summary.
    Placeholder summarisation: keep first sentence + last sentence,
    plus a word-count note. In production this would call an LLM.
    """
    sentences = re.split(r'(?<=[.!?])\s+', raw_text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]

    if len(sentences) == 0:
        return "[empty chunk]"
    elif len(sentences) == 1:
        summary = sentences[0]
    else:
        summary = sentences[0] + " ... " + sentences[-1]

    word_count = len(raw_text.split())
    return f"[Summary ~{word_count} words] {summary}"


# Rule-based category keywords (theme → trigger words)
CATEGORY_RULES = {
    "Technology & AI":    ["ai", "machine learning", "model", "neural", "algorithm",
                            "software", "data", "compute", "training", "llm", "nlp"],
    "Finance & Business": ["revenue", "profit", "market", "investment", "capital",
                            "growth", "economy", "stock", "bank", "financial"],
    "Science & Research": ["research", "study", "experiment", "hypothesis", "findings",
                            "analysis", "biology", "physics", "chemistry", "result"],
    "Health & Medicine":  ["patient", "treatment", "clinical", "drug", "therapy",
                            "diagnosis", "health", "disease", "medical", "hospital"],
    "Legal & Policy":     ["law", "regulation", "compliance", "court", "policy",
                            "contract", "rights", "legislation", "government", "legal"],
    "General":            [],   # fallback
}


def layer2_category(raw_text: str) -> str:
    """
    Layer 2 – Category / Theme Label.
    Rule-based: score each category by keyword hits in lowercased text.
    Returns the highest-scoring category.
    """
    text_lower = raw_text.lower()
    scores     = {}

    for category, keywords in CATEGORY_RULES.items():
        if not keywords:
            scores[category] = 0
            continue
        score = sum(1 for kw in keywords if kw in text_lower)
        scores[category] = score

    # Pick highest; fall back to 'General' on tie/zero
    best = max(scores, key=scores.get)
    if scores[best] == 0:
        best = "General"

    return best


def layer3_distilled(raw_text: str) -> dict:
    """
    Layer 3 – Distilled Knowledge.
    Returns:
        keywords   : top-10 non-stopword tokens by frequency
        mock_embed : a 8-dim pseudo-embedding derived from char frequencies
                     (deterministic stand-in; replace with real embedder)
    """
    stopwords = {
        "the","a","an","and","or","but","in","on","at","to","for","of","with",
        "by","from","is","are","was","were","be","been","being","have","has",
        "had","do","does","did","will","would","could","should","may","might",
        "shall","can","this","that","these","those","i","we","you","he","she",
        "it","they","my","your","his","her","its","our","their","not","as","so",
        "if","then","than","up","down","out","about","what","which","who","how",
    }
    tokens   = re.findall(r'\b[a-z]{3,}\b', raw_text.lower())
    filtered = [t for t in tokens if t not in stopwords]
    counts   = Counter(filtered)
    top_kws  = [word for word, _ in counts.most_common(10)]

    # Deterministic mock embedding: 8 dimensions from char-ngram frequencies
    vec = [0.0] * 8
    for i, char in enumerate(raw_text[:500]):
        vec[ord(char) % 8] += 1.0
    magnitude = math.sqrt(sum(x * x for x in vec)) or 1.0
    vec       = [round(x / magnitude, 4) for x in vec]

    return {"keywords": top_kws, "mock_embedding": vec}


# ---------------------------------------------------------------------------
# SECTION 3: Build the Pyramid
# ---------------------------------------------------------------------------

def build_pyramid(text: str) -> list[dict]:
    """
    Ingest a document string → list of Knowledge Pyramid entries.

    Each entry:
        chunk_id     : int
        layer0_raw   : str   (raw text)
        layer1_summary : str
        layer2_category : str
        layer3_distilled : dict
    """
    chunks  = sliding_window_chunks(text)
    pyramid = []

    for chunk in chunks:
        raw        = layer0_raw(chunk)
        summary    = layer1_summary(raw)
        category   = layer2_category(raw)
        distilled  = layer3_distilled(raw)

        pyramid.append({
            "chunk_id":          chunk["chunk_id"],
            "layer0_raw":        raw,
            "layer1_summary":    summary,
            "layer2_category":   category,
            "layer3_distilled":  distilled,
        })

    return pyramid


# ---------------------------------------------------------------------------
# SECTION 4: Retrieval via Cosine Similarity
# ---------------------------------------------------------------------------

def _text_vector(text: str) -> dict:
    """
    Convert text to a normalised word-frequency vector (dict).
    Used for cosine similarity computation.
    """
    tokens   = re.findall(r'\b[a-z]{3,}\b', text.lower())
    counts   = Counter(tokens)
    total    = sum(counts.values()) or 1
    return {w: c / total for w, c in counts.items()}


def _cosine_sim(vec_a: dict, vec_b: dict) -> float:
    """Cosine similarity between two frequency dicts."""
    shared  = set(vec_a) & set(vec_b)
    dot     = sum(vec_a[w] * vec_b[w] for w in shared)
    mag_a   = math.sqrt(sum(v * v for v in vec_a.values())) or 1.0
    mag_b   = math.sqrt(sum(v * v for v in vec_b.values())) or 1.0
    return dot / (mag_a * mag_b)


def retrieve(query: str, pyramid: list[dict], top_k: int = 3) -> list[dict]:
    """
    Find the top-k most relevant pyramid entries for a query.

    Scores are computed per entry as the maximum cosine similarity
    across all 4 pyramid layers (represented as text).

    Returns a sorted list of dicts with keys:
        chunk_id, best_layer, score, snippet
    """
    q_vec   = _text_vector(query)
    results = []

    for entry in pyramid:
        layer_texts = {
            "layer0_raw":        entry["layer0_raw"],
            "layer1_summary":    entry["layer1_summary"],
            "layer2_category":   entry["layer2_category"],
            "layer3_keywords":   " ".join(entry["layer3_distilled"]["keywords"]),
        }

        best_score = 0.0
        best_layer = "layer0_raw"

        for layer_name, layer_text in layer_texts.items():
            sim = _cosine_sim(q_vec, _text_vector(layer_text))
            if sim > best_score:
                best_score = sim
                best_layer = layer_name

        results.append({
            "chunk_id":   entry["chunk_id"],
            "best_layer": best_layer,
            "score":      round(best_score, 4),
            "category":   entry["layer2_category"],
            "snippet":    entry["layer1_summary"][:200],
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_k]


# ---------------------------------------------------------------------------
# SECTION 5: Demo / CLI
# ---------------------------------------------------------------------------

SAMPLE_DOCUMENT = """
Artificial intelligence (AI) is transforming industries worldwide. Machine learning models,
particularly large language models (LLMs), are being deployed in healthcare, finance, and
legal sectors at an unprecedented rate. These neural networks require vast amounts of
training data and significant compute resources.

In the financial sector, AI-driven algorithms are now managing billions of dollars in assets.
Revenue from AI-powered trading systems grew by 40% last year, and banks are investing
heavily in AI infrastructure. The stock market now reacts within milliseconds to AI signals.

Clinical research has also been revolutionised. Patient outcomes are improving thanks to AI
diagnosis tools. Drug discovery pipelines that once took 10 years now complete in 3 with
AI assistance. Several studies confirm that treatment personalisation through machine
learning reduces hospital readmission rates significantly.

Legal compliance teams are adopting AI to process regulatory documents. Government policy
on AI governance is still evolving, but several jurisdictions have enacted legislation
requiring explainability in algorithmic decision-making. Contract analysis, rights management,
and court document summarisation are among the most popular applications.

Researchers continue to push the boundaries of what AI can do. Recent experiments in
multimodal models combine vision and language understanding. Hypothesis-driven research
workflows powered by AI are shortening the time from experiment design to findings by 60%.
The next frontier is AI that can autonomously design and run experiments.
"""


def main():
    print("=" * 60)
    print("  Knowledge Pyramid Ingestion System – Demo")
    print("=" * 60)

    # Build pyramid
    pyramid = build_pyramid(SAMPLE_DOCUMENT)
    print(f"\nDocument ingested into {len(pyramid)} pyramid entries.\n")

    for entry in pyramid:
        print(f"  Chunk {entry['chunk_id']}:")
        print(f"    Layer 0 (raw)      : {entry['layer0_raw'][:80]}...")
        print(f"    Layer 1 (summary)  : {entry['layer1_summary'][:80]}...")
        print(f"    Layer 2 (category) : {entry['layer2_category']}")
        print(f"    Layer 3 (keywords) : {entry['layer3_distilled']['keywords'][:5]}")
        print()

    # Query retrieval
    queries = [
        "How is AI used in healthcare and drug discovery?",
        "What are the legal and regulatory challenges of AI?",
        "Tell me about AI in financial markets and trading.",
    ]

    print("=" * 60)
    print("  Query Retrieval Demo")
    print("=" * 60)

    for q in queries:
        print(f"\nQuery: {q!r}")
        results = retrieve(q, pyramid, top_k=2)
        for rank, r in enumerate(results, 1):
            print(f"  [{rank}] Chunk {r['chunk_id']} | Layer: {r['best_layer']} "
                  f"| Score: {r['score']:.4f} | Category: {r['category']}")
            print(f"       {r['snippet'][:120]}...")

    # Save pyramid to JSON for inspection
    with open("pyramid_output.json", "w") as f:
        json.dump(pyramid, f, indent=2)
    print("\n[Pyramid saved to pyramid_output.json]")


if __name__ == "__main__":
    main()
