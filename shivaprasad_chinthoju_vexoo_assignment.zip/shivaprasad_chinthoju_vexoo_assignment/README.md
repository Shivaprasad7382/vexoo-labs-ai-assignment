# Vexoo Labs AI Engineer Assignment

## Repository Structure

```
├── part1_ingestion.py          # Sliding Window + Knowledge Pyramid (Part 1)
├── part2_gsm8k_training.py     # GSM8K LoRA fine-tuning (Part 2)
├── bonus_reasoning_adapter.py  # Plug-and-play Reasoning Adapter (Bonus)
├── requirements.txt            # Python dependencies
└── README.md
```

---

## Part 1 – Document Ingestion + Knowledge Pyramid

### What it does

Ingests any plain-text document through a 2-page sliding window (2 000 chars/page, 50 % overlap), then builds a 4-layer Knowledge Pyramid for each window chunk:

| Layer | Name | Method |
|-------|------|--------|
| 0 | Raw Text | Verbatim window content |
| 1 | Chunk Summary | First + last sentence + word count (placeholder) |
| 2 | Category / Theme | Rule-based keyword scoring across 6 domains |
| 3 | Distilled Knowledge | Top-10 keywords + 8-dim deterministic mock embedding |

At query time, cosine similarity over word-frequency vectors selects the best-matching chunk and pyramid layer.

### Setup

```bash
pip install -r requirements.txt   # no extra deps needed for Part 1 (stdlib only)
python part1_ingestion.py
```

### Output

- Console: per-chunk pyramid summary + ranked query results  
- `pyramid_output.json`: full pyramid structure for inspection

### Customisation

| Variable | File | Purpose |
|----------|------|---------|
| `CHARS_PER_PAGE` | part1_ingestion.py | Page size in characters |
| `WINDOW_PAGES` | part1_ingestion.py | Window width (pages) |
| `CATEGORY_RULES` | part1_ingestion.py | Add / edit domain keyword lists |

---

## Part 2 – GSM8K LoRA Fine-Tuning

### What it does

Fine-tunes **LLaMA 3.2 1B Instruct** on 3 000 GSM8K training samples using 4-bit quantisation + LoRA (rank 8, targets `q_proj` / `v_proj`). Evaluates exact-match accuracy on 1 000 test samples.

### Requirements

- CUDA GPU with ≥ 16 GB VRAM (tested: A100 40 GB)
- Python 3.10+

### Setup

```bash
pip install -r requirements.txt
huggingface-cli login   # needed to download LLaMA 3.2 weights
```

### Run (real training)

```bash
python part2_gsm8k_training.py
```

### Dry-run (no GPU needed)

Validates data loading, formatting, and tokenisation; simulates loss curves.

```bash
SIMULATE_TRAINING=true python part2_gsm8k_training.py
```

### Outputs

| File | Contents |
|------|----------|
| `gsm8k_lora_output/training_log.json` | Loss + LR per optimisation step |
| `gsm8k_lora_output/eval_results.json` | Final accuracy + hyperparameters |
| `gsm8k_lora_output/adapter_model.bin` | Saved LoRA weights |

### Key hyperparameters

| Parameter | Value |
|-----------|-------|
| Base model | meta-llama/Llama-3.2-1B-Instruct |
| Quantisation | 4-bit NF4 (bitsandbytes) |
| LoRA rank | 8 |
| LoRA alpha | 32 |
| Target modules | q_proj, v_proj |
| Learning rate | 2e-4 |
| Effective batch | 16 (batch 4 × grad accum 4) |
| Epochs | 3 |
| Max seq length | 512 tokens |

---

## Bonus – Reasoning-Aware Adapter

### What it does

A plug-and-play routing component that:

1. Classifies the input query into one of 6 types (Math, Legal, Medical, Code, Factual, Conversational) using regex-based keyword scoring.
2. Activates the appropriate reasoning strategy (Chain-of-Thought for math, Rule-Lookup for legal, Retrieve-then-Verify for factual, etc.).
3. Returns the answer alongside a step-by-step reasoning trace and confidence flag.

New domains can be added with a single `adapter.register(QueryType.X, handler_fn)` call.

### Run

```bash
python bonus_reasoning_adapter.py
```

No additional dependencies beyond Python stdlib.

---

## requirements.txt quick reference

```
datasets>=2.19
transformers>=4.44
peft>=0.11
bitsandbytes>=0.43
torch>=2.2
accelerate>=0.30
```

Install all:
```bash
pip install -r requirements.txt
```

---

## Notes

- Part 1 uses Python standard library only (no ML frameworks required).
- Part 2 requires a CUDA GPU for real training; use `SIMULATE_TRAINING=true` otherwise.
- The Bonus adapter uses simulated LLM responses; replace `_simulate_llm()` with a real API call for production use.
