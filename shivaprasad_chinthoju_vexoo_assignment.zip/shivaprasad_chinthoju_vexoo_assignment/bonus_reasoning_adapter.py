"""
bonus_reasoning_adapter.py
--------------------------
Plug-and-play Reasoning-Aware Adapter

Design Philosophy
-----------------
Real-world queries are heterogeneous: a math word problem, a legal clause
interpretation, and a trivia question each benefit from a different reasoning
strategy. Rather than routing every query through the same LLM prompt, this
adapter:

  1. Detects the query type using lightweight classifiers.
  2. Activates the appropriate reasoning strategy (chain-of-thought, rule lookup,
     retrieval, etc.).
  3. Returns both the answer and a reasoning trace for transparency.

This file is an architecture demonstration. Routing logic uses deterministic
rules and simulated LLM calls. Drop in real LLM calls or fine-tuned classifiers
at the marked points to make it production-ready.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from enum import Enum


# ---------------------------------------------------------------------------
# 1. Query type taxonomy
# ---------------------------------------------------------------------------

class QueryType(str, Enum):
    MATH        = "math"          # arithmetic, algebra, word problems
    LEGAL       = "legal"         # contract, compliance, statute interpretation
    MEDICAL     = "medical"       # symptoms, drugs, diagnoses
    CODE        = "code"          # programming, debugging, algorithms
    FACTUAL     = "factual"       # general knowledge / lookup
    CONVERSATIONAL = "conversational"  # small talk, opinions, open-ended


# ---------------------------------------------------------------------------
# 2. Classifier: detect query type
# ---------------------------------------------------------------------------

# Keyword signatures for each domain (lightweight, zero-dependency detection)
_SIGNATURES: dict[QueryType, list[str]] = {
    QueryType.MATH:    [
        r"\b(calculate|compute|how many|total|sum|difference|product|percent|ratio"
        r"|equation|solve|algebra|arithmetic|geometry|probability)\b",
        r"\d+\s*[\+\-\*/]\s*\d+",   # inline arithmetic
        r"\$[\d,]+",                  # dollar amounts
    ],
    QueryType.LEGAL:   [
        r"\b(contract|clause|liability|indemnity|jurisdiction|statute|regulation"
        r"|comply|legal|law|court|patent|intellectual property|gdpr|terms of service)\b",
    ],
    QueryType.MEDICAL: [
        r"\b(symptom|diagnosis|treatment|drug|dosage|patient|disease|clinical"
        r"|therapy|medication|side effect|prescription|hospital|medical)\b",
    ],
    QueryType.CODE:    [
        r"\b(function|class|variable|bug|error|runtime|compile|algorithm|api"
        r"|python|javascript|java|sql|debug|code|script|loop|array|recursion)\b",
        r"```",                       # code fences
        r"def |import |#include",     # language keywords
    ],
    QueryType.FACTUAL: [
        r"\b(who|what|when|where|which|how|why|history|capital|president"
        r"|year|country|founded|invented|mean|definition)\b",
    ],
}


def classify_query(query: str) -> QueryType:
    """
    Classify a query into one of the QueryType values.

    Strategy:
      - Score each type by counting regex pattern matches in the query.
      - Return the highest-scoring type; fall back to CONVERSATIONAL.

    NOTE: Replace with a fine-tuned text classifier or an LLM call for
    production use — this rule-based approach is intentionally transparent.
    """
    q_lower = query.lower()
    scores: dict[QueryType, int] = {qt: 0 for qt in QueryType}

    for query_type, patterns in _SIGNATURES.items():
        for pattern in patterns:
            if re.search(pattern, q_lower, re.IGNORECASE):
                scores[query_type] += 1

    best_type  = max(scores, key=scores.get)
    best_score = scores[best_type]

    return best_type if best_score > 0 else QueryType.CONVERSATIONAL


# ---------------------------------------------------------------------------
# 3. Reasoning strategies
# ---------------------------------------------------------------------------

@dataclass
class ReasoningResult:
    query_type:     QueryType
    strategy_used:  str
    reasoning_trace: list[str]       # step-by-step trace for transparency
    answer:         str
    confidence:     str              # "high" | "medium" | "low"
    flags:          dict = field(default_factory=dict)   # metadata for callers


def _simulate_llm(prompt: str, system: str = "") -> str:
    """
    Simulated LLM call.
    Replace this function body with:
        import anthropic
        client = anthropic.Anthropic()
        msg = client.messages.create(model="claude-opus-4-5", ...)
        return msg.content[0].text
    """
    return f"[LLM RESPONSE – replace _simulate_llm() with real API call]\nPrompt received: {prompt[:80]}…"


def strategy_math(query: str) -> ReasoningResult:
    """
    Chain-of-thought math reasoning.
    Structured prompt that forces step-by-step decomposition.
    """
    cot_prompt = (
        f"Solve the following math problem step by step.\n"
        f"Show each calculation explicitly.\n"
        f"End with: 'Answer: <number>'\n\n"
        f"Problem: {query}"
    )
    trace = [
        "Step 1: Parse problem entities and quantities.",
        "Step 2: Identify the operation(s) needed.",
        "Step 3: Execute calculations in order.",
        "Step 4: Verify units and reasonableness.",
    ]
    answer = _simulate_llm(cot_prompt, system="You are a precise math solver.")
    return ReasoningResult(
        query_type=QueryType.MATH,
        strategy_used="Chain-of-Thought (Math)",
        reasoning_trace=trace,
        answer=answer,
        confidence="high",
        flags={"prompt_style": "CoT", "verify_units": True},
    )


def strategy_legal(query: str) -> ReasoningResult:
    """
    Rule-lookup + citation-based legal reasoning.
    Enforces citation of relevant statute or clause; avoids legal advice framing.
    """
    legal_prompt = (
        f"Interpret the following legal question based on general legal principles.\n"
        f"Cite relevant concepts (statute type, clause category, jurisdiction notes).\n"
        f"End with a disclaimer that this is not legal advice.\n\n"
        f"Query: {query}"
    )
    trace = [
        "Step 1: Identify jurisdiction and legal domain.",
        "Step 2: Match query to applicable legal principle or statute category.",
        "Step 3: Apply rule to facts presented.",
        "Step 4: Note any ambiguities requiring professional counsel.",
    ]
    answer = _simulate_llm(legal_prompt, system="You are a legal research assistant.")
    return ReasoningResult(
        query_type=QueryType.LEGAL,
        strategy_used="Rule-Lookup + Citation",
        reasoning_trace=trace,
        answer=answer,
        confidence="medium",
        flags={"disclaimer": True, "jurisdiction_check": True},
    )


def strategy_medical(query: str) -> ReasoningResult:
    """
    Evidence-based medical reasoning with safety guardrails.
    Always includes a 'consult a professional' disclaimer.
    """
    med_prompt = (
        f"Answer the following medical question using evidence-based information.\n"
        f"Do NOT prescribe or diagnose. Always recommend consulting a licensed physician.\n\n"
        f"Query: {query}"
    )
    trace = [
        "Step 1: Identify medical domain (symptoms / drug / procedure).",
        "Step 2: Retrieve relevant clinical knowledge.",
        "Step 3: Apply differential reasoning if symptoms are mentioned.",
        "Step 4: Attach safety disclaimer.",
    ]
    answer = _simulate_llm(med_prompt, system="You are a medical information assistant.")
    return ReasoningResult(
        query_type=QueryType.MEDICAL,
        strategy_used="Evidence-Based Medical Reasoning",
        reasoning_trace=trace,
        answer=answer,
        confidence="medium",
        flags={"safety_disclaimer": True, "no_prescription": True},
    )


def strategy_code(query: str) -> ReasoningResult:
    """
    Scratchpad-based code reasoning: plan → write → explain.
    """
    code_prompt = (
        f"Answer the following programming question.\n"
        f"Plan the approach first, then provide working code with inline comments.\n\n"
        f"Query: {query}"
    )
    trace = [
        "Step 1: Identify programming language / framework.",
        "Step 2: Decompose problem into sub-tasks.",
        "Step 3: Write solution with edge-case handling.",
        "Step 4: Provide example input / output.",
    ]
    answer = _simulate_llm(code_prompt, system="You are an expert software engineer.")
    return ReasoningResult(
        query_type=QueryType.CODE,
        strategy_used="Plan-then-Code Scratchpad",
        reasoning_trace=trace,
        answer=answer,
        confidence="high",
        flags={"include_examples": True, "language_detection": True},
    )


def strategy_factual(query: str) -> ReasoningResult:
    """
    Retrieve-then-verify factual reasoning.
    In production, retrieves from a vector store before generating.
    """
    fact_prompt = (
        f"Answer the following factual question concisely and accurately.\n"
        f"If uncertain, say so explicitly.\n\n"
        f"Query: {query}"
    )
    trace = [
        "Step 1: Identify key entities in query.",
        "Step 2: Retrieve relevant knowledge (RAG / web search).",
        "Step 3: Synthesise a concise answer.",
        "Step 4: Flag any uncertainty.",
    ]
    answer = _simulate_llm(fact_prompt, system="You are a knowledgeable assistant.")
    return ReasoningResult(
        query_type=QueryType.FACTUAL,
        strategy_used="Retrieve-then-Verify",
        reasoning_trace=trace,
        answer=answer,
        confidence="high",
        flags={"rag_enabled": True, "uncertainty_flagging": True},
    )


def strategy_conversational(query: str) -> ReasoningResult:
    """Default open-ended conversational response."""
    conv_prompt = f"Respond naturally and helpfully to: {query}"
    trace = ["Step 1: Parse intent.", "Step 2: Generate friendly response."]
    answer = _simulate_llm(conv_prompt)
    return ReasoningResult(
        query_type=QueryType.CONVERSATIONAL,
        strategy_used="Conversational",
        reasoning_trace=trace,
        answer=answer,
        confidence="low",
        flags={},
    )


# ---------------------------------------------------------------------------
# 4. The Adapter (routing hub)
# ---------------------------------------------------------------------------

# Strategy registry: maps QueryType → handler function
_STRATEGY_REGISTRY: dict[QueryType, callable] = {
    QueryType.MATH:          strategy_math,
    QueryType.LEGAL:         strategy_legal,
    QueryType.MEDICAL:       strategy_medical,
    QueryType.CODE:          strategy_code,
    QueryType.FACTUAL:       strategy_factual,
    QueryType.CONVERSATIONAL: strategy_conversational,
}


class ReasoningAdapter:
    """
    Plug-and-play reasoning router.

    Usage:
        adapter = ReasoningAdapter()
        result  = adapter.reason("If I have 3 apples and buy 5 more, how many do I have?")
        print(result.answer)

    Extending:
        To add a new domain, register a new strategy:
            adapter.register(QueryType.SCIENCE, my_science_strategy_fn)
    """

    def __init__(self):
        self._registry = dict(_STRATEGY_REGISTRY)

    def register(self, query_type: QueryType, handler: callable) -> None:
        """Register or override a strategy handler."""
        self._registry[query_type] = handler
        print(f"[Adapter] Registered handler for {query_type.value!r}")

    def reason(self, query: str, override_type: QueryType | None = None) -> ReasoningResult:
        """
        Process a query through the appropriate reasoning strategy.

        Args:
            query:         Natural-language input from the user.
            override_type: Force a specific QueryType (bypass classifier).

        Returns:
            ReasoningResult with answer, trace, and metadata.
        """
        detected_type = override_type or classify_query(query)
        handler       = self._registry.get(detected_type, strategy_conversational)
        result        = handler(query)
        return result


# ---------------------------------------------------------------------------
# 5. Demo
# ---------------------------------------------------------------------------

def demo():
    adapter = ReasoningAdapter()

    test_cases = [
        "If a train travels 60 km/h for 2.5 hours, how far does it go?",
        "Does a non-compete clause remain enforceable after company acquisition?",
        "What are the common symptoms of appendicitis?",
        "Write a Python function to find all prime numbers up to N using a sieve.",
        "Who invented the World Wide Web?",
        "What do you think about modern art?",
    ]

    print("=" * 65)
    print("  Reasoning-Aware Adapter – Demo")
    print("=" * 65)

    for query in test_cases:
        result = adapter.reason(query)
        print(f"\nQuery    : {query}")
        print(f"Detected : {result.query_type.value}")
        print(f"Strategy : {result.strategy_used}")
        print(f"Confidence: {result.confidence}")
        print(f"Trace    :")
        for step in result.reasoning_trace:
            print(f"   {step}")
        print(f"Flags    : {result.flags}")
        print("-" * 65)


if __name__ == "__main__":
    demo()
